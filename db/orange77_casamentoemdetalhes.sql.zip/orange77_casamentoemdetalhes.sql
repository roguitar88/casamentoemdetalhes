-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 21-Abr-2020 às 22:40
-- Versão do servidor: 10.4.8-MariaDB
-- versão do PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `orange77_casamentoemdetalhes`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `fotos`
--

CREATE TABLE `fotos` (
  `id` int(11) NOT NULL,
  `iddocasal` int(11) NOT NULL,
  `nomediretorio` varchar(400) NOT NULL,
  `tamanho` varchar(200) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `fotos`
--

INSERT INTO `fotos` (`id`, `iddocasal`, `nomediretorio`, `tamanho`, `data`) VALUES
(3, 2, '1260615229.jpg', '0.12761783599854', '2020-02-02 19:34:02'),
(5, 2, '1640030025.jpg', '0.13204765319824', '2020-02-02 19:35:18'),
(8, 2, '427058550.jpg', '0.17352867126465', '2020-02-02 21:33:52'),
(9, 2, '933492326.jpg', '0.13567161560059', '2020-02-02 21:40:49'),
(10, 2, '2040485975.jpg', '0.59085369110107', '2020-02-02 21:53:53');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ipn_notifications`
--

CREATE TABLE `ipn_notifications` (
  `id` int(50) NOT NULL,
  `transactionid` varchar(200) CHARACTER SET utf8mb4 NOT NULL,
  `subscriptionid` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `payer_id` varchar(200) NOT NULL,
  `payer_email` varchar(200) NOT NULL,
  `subject` varchar(400) CHARACTER SET utf8mb4 NOT NULL,
  `message` varchar(2000) CHARACTER SET utf8mb4 NOT NULL,
  `chosenplan` varchar(100) CHARACTER SET utf8mb4 NOT NULL,
  `paypal_environment` varchar(200) CHARACTER SET utf8mb4 NOT NULL,
  `txn_type` varchar(200) NOT NULL,
  `payment_status` varchar(200) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `paypal_amount` decimal(13,2) NOT NULL,
  `paypal_fee` decimal(13,2) NOT NULL,
  `paypaldate` varchar(300) CHARACTER SET utf8mb4 NOT NULL,
  `datetime` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `ipn_notifications`
--

INSERT INTO `ipn_notifications` (`id`, `transactionid`, `subscriptionid`, `payer_id`, `payer_email`, `subject`, `message`, `chosenplan`, `paypal_environment`, `txn_type`, `payment_status`, `currency`, `paypal_amount`, `paypal_fee`, `paypaldate`, `datetime`) VALUES
(662, '', '', '6MVQSRK88TGQS', 'englishup.civic@gmail.com', 'Mass Pay notification', 'This message is to confirm that a mass pay was executed. For further details and administrative purposes, enter: https://www.sandbox.paypal.com/br/cgi-bin/webscr?cmd=_display-ipns-history and check the IPNS history. IPN fired in 19:02:54 Nov 25, 2019 PST.', '', 'SANDBOX', 'masspay', 'Completed', '', '0.00', '0.00', '19:02:54 Nov 25, 2019 PST', '2019-11-26 03:04:08');

-- --------------------------------------------------------

--
-- Estrutura da tabela `paypalswitch`
--

CREATE TABLE `paypalswitch` (
  `id` int(11) NOT NULL,
  `sandbox` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `paypalswitch`
--

INSERT INTO `paypalswitch` (`id`, `sandbox`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios_cadastrados`
--

CREATE TABLE `usuarios_cadastrados` (
  `id` int(11) NOT NULL,
  `credencial` int(11) NOT NULL,
  `localfotodeperfil` varchar(400) NOT NULL,
  `email` varchar(200) NOT NULL,
  `senha` varchar(200) NOT NULL,
  `resetar_codigo_senha` varchar(400) NOT NULL,
  `nomedeusuario` varchar(200) NOT NULL,
  `nomeprincipal` varchar(200) NOT NULL,
  `nomedonoivo` varchar(500) NOT NULL,
  `nomedanoiva` varchar(500) NOT NULL,
  `sobrenome` varchar(200) NOT NULL,
  `datadocasamento` datetime NOT NULL,
  `sexo` varchar(200) NOT NULL,
  `datadenascimento` date NOT NULL,
  `fone` varchar(200) NOT NULL,
  `whatsapp` int(11) NOT NULL,
  `pais` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `cidade` varchar(200) NOT NULL,
  `endereco` varchar(1000) NOT NULL,
  `cliente` int(11) NOT NULL,
  `nivel` int(11) NOT NULL,
  `ipdousuario` varchar(300) NOT NULL,
  `codigo_ativacao` varchar(200) NOT NULL,
  `ativado` int(11) NOT NULL,
  `desativar` int(11) NOT NULL,
  `paleta` int(11) NOT NULL,
  `textoestilo` int(11) NOT NULL,
  `cordotitulo` int(11) NOT NULL,
  `divisor` int(11) NOT NULL,
  `fontetexto` int(11) NOT NULL,
  `cordotexto` int(11) NOT NULL,
  `template` int(11) NOT NULL,
  `nossahistoria` text NOT NULL,
  `nossahistoriafoto` varchar(400) NOT NULL,
  `fotoinicio` varchar(400) NOT NULL,
  `textoinicio` text NOT NULL,
  `paypal_canceled` int(50) NOT NULL,
  `paypal_suspended` int(50) NOT NULL,
  `paypal_firstname` varchar(100) NOT NULL,
  `paypal_lastname` varchar(100) NOT NULL,
  `paypal_email` varchar(100) NOT NULL,
  `payer_id` varchar(200) NOT NULL,
  `paypal_subscriptionid` varchar(100) NOT NULL,
  `paypal_transaction_id` varchar(100) NOT NULL,
  `paypal_url` varchar(500) NOT NULL,
  `paypal_chosenplan` varchar(50) NOT NULL,
  `paypal_paymentstatus` varchar(100) NOT NULL,
  `paypal_paymentdate` varchar(100) NOT NULL,
  `paypal_clientcountry` varchar(100) NOT NULL,
  `paypal_transactionfee` decimal(13,2) NOT NULL,
  `paypal_currency` varchar(20) NOT NULL,
  `paypal_env` varchar(50) NOT NULL,
  `read1` int(11) NOT NULL,
  `paid` int(50) NOT NULL,
  `possible_duplicate` int(11) NOT NULL,
  `free` int(11) NOT NULL,
  `iddoafiliadovinculado` int(11) NOT NULL,
  `codigo_afiliado` varchar(200) NOT NULL,
  `data` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios_cadastrados`
--

INSERT INTO `usuarios_cadastrados` (`id`, `credencial`, `localfotodeperfil`, `email`, `senha`, `resetar_codigo_senha`, `nomedeusuario`, `nomeprincipal`, `nomedonoivo`, `nomedanoiva`, `sobrenome`, `datadocasamento`, `sexo`, `datadenascimento`, `fone`, `whatsapp`, `pais`, `state`, `cidade`, `endereco`, `cliente`, `nivel`, `ipdousuario`, `codigo_ativacao`, `ativado`, `desativar`, `paleta`, `textoestilo`, `cordotitulo`, `divisor`, `fontetexto`, `cordotexto`, `template`, `nossahistoria`, `nossahistoriafoto`, `fotoinicio`, `textoinicio`, `paypal_canceled`, `paypal_suspended`, `paypal_firstname`, `paypal_lastname`, `paypal_email`, `payer_id`, `paypal_subscriptionid`, `paypal_transaction_id`, `paypal_url`, `paypal_chosenplan`, `paypal_paymentstatus`, `paypal_paymentdate`, `paypal_clientcountry`, `paypal_transactionfee`, `paypal_currency`, `paypal_env`, `read1`, `paid`, `possible_duplicate`, `free`, `iddoafiliadovinculado`, `codigo_afiliado`, `data`) VALUES
(1, 2, '1088714077.jpg', 'rogeriobsoares5@gmail.com', 'cabecadebagre', 'ca0173d0', 'roguitar', 'Rogerio', '', '', 'Soares', '2020-02-13 00:00:00', 'male', '1988-07-30', '62982570993', 0, 'Brazil', 'Goias', 'Goiania', 'Av. Vieira Santos', 0, 0, '177.13.248.222', '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur consectetur aliquam ligula, vitae elementum nisi sollicitudin non. Praesent nunc justo, auctor bibendum dictum sit amet, tempus sed nulla. Nam ac dui pellentesque, euismod sapien consectetur, feugiat ante. Nam risus nibh, dapibus ut gravida id, accumsan at enim. Sed sit amet hendrerit lacus. Vestibulum eget libero sagittis, mollis magna quis, consectetur mi. In vulputate rutrum fermentum. Duis convallis enim at sollicitudin efficitur. In eu velit vel enim tempor accumsan sed et neque. Nullam varius malesuada magna, a convallis mi sodales et. Pellentesque a dolor efficitur, euismod est sed, congue mi. Cras tristique augue sapien, a iaculis nisi elementum quis. Sed quis lectus nisl. Mauris fringilla fringilla ligula non pellentesque. Fusce turpis neque, condimentum eget felis id, tristique sodales ex. Praesent interdum mi a nisi auctor, sagittis placerat leo auctor.  Duis vulputate dictum semper. Etiam ultrices convallis egestas. Aliquam posuere pulvinar magna, ut tempus neque bibendum vel. Morbi ut enim vel nisi fringilla efficitur. Suspendisse gravida ligula ut pretium fermentum. Sed dictum lacus felis, at consequat nisl posuere in. Curabitur sed purus ac felis venenatis euismod quis et enim. Maecenas sollicitudin nulla vel ligula dapibus luctus. Proin pharetra lorem vitae hendrerit finibus. In finibus risus neque, sed pulvinar mauris egestas vitae. Maecenas dignissim, urna quis suscipit porta, lorem tortor mollis nibh, sit amet iaculis nunc sapien non tellus. 					   Sed eu elementum odio. Vestibulum venenatis tellus ac elit finibus gravida. Donec non commodo ex. Sed venenatis sit amet dolor non facilisis. Suspendisse sit amet ultrices dolor. Fusce arcu dui, consectetur at faucibus nec, viverra at dolor. Donec condimentum odio erat, sed vestibulum mauris malesuada tincidunt. Cras convallis venenatis felis vel condimentum. In eget dapibus nunc. Mauris elementum cursus urna, id fringilla arcu euismod sit amet. Sed mollis turpis at ante porttitor gravida. Aliquam aliquam massa eget blandit feugiat.													', 'default.jpg', 'default.jpg', 'E tudo começou há um tempo atrás na ilha do sol. Destino te mandou de volta para o meu cais. Hiê ê! No coração ficou lembranças de nós dois, como ferida aberta, como tatuagem. Ô Milla! Mil e uma noites de amor com você, na praia, num barco, no farol apagado, num moinho abandonado, em Mar Grande, alto astral... Lá em Hollywood, pra de tudo rolar, vendo estrelas caindo, vendo a noite passar, eu e você, na ilha do sol, na ilha do sol.', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0.00', '', '', 0, 0, 0, 0, 0, '', '2020-04-21 20:27:34'),
(2, 0, '', 'jeffersonecarla@gmail.com', '36459628', '', 'jeff&carlitta', 'Jefferson', 'Jefferson Mattos Cavalcante', 'Carla Santos Gonçalves', 'Mattos Cavalcante', '2020-07-30 00:00:00', 'male', '1988-07-30', '+55989099343234', 1, 'Algeria', 'Batna', 'Batna', '19th Street, 401, flat 13', 1, 0, '177.13.251.147', 'bae22964', 1, 0, 7, 0, 11, 6, 2, 3, 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur consectetur aliquam ligula, vitae elementum nisi sollicitudin non. Praesent nunc justo, auctor bibendum dictum sit amet, tempus sed nulla. Nam ac dui pellentesque, euismod sapien consectetur, feugiat ante. Nam risus nibh, dapibus ut gravida id, accumsan at enim. Sed sit amet hendrerit lacus. Vestibulum eget libero sagittis, mollis magna quis, consectetur mi. In vulputate rutrum fermentum. Duis convallis enim at sollicitudin efficitur. In eu velit vel enim tempor accumsan sed et neque. Nullam varius malesuada magna, a convallis mi sodales et. Pellentesque a dolor efficitur, euismod est sed, congue mi. Cras tristique augue sapien, a iaculis nisi elementum quis. Sed quis lectus nisl. Mauris fringilla fringilla ligula non pellentesque. Fusce turpis neque, condimentum eget felis id, tristique sodales ex. Praesent interdum mi a nisi auctor, sagittis placerat leo auctor.\r\n\r\nDuis vulputate dictum semper. Etiam ultrices convallis egestas. Aliquam posuere pulvinar magna, ut tempus neque bibendum vel. Morbi ut enim vel nisi fringilla efficitur. Suspendisse gravida ligula ut pretium fermentum. Sed dictum lacus felis, at consequat nisl posuere in. Curabitur sed purus ac felis venenatis euismod quis et enim. Maecenas sollicitudin nulla vel ligula dapibus luctus. Proin pharetra lorem vitae hendrerit finibus. In finibus risus neque, sed pulvinar mauris egestas vitae. Maecenas dignissim, urna quis suscipit porta, lorem tortor mollis nibh, sit amet iaculis nunc sapien non tellus. 					 \r\n\r\nSed eu elementum odio. Vestibulum venenatis tellus ac elit finibus gravida. Donec non commodo ex. Sed venenatis sit amet dolor non facilisis. Suspendisse sit amet ultrices dolor. Fusce arcu dui, consectetur at faucibus nec, viverra at dolor. Donec condimentum odio erat, sed vestibulum mauris malesuada tincidunt. Cras convallis venenatis felis vel condimentum. In eget dapibus nunc. Mauris elementum cursus urna, id fringilla arcu euismod sit amet. Sed mollis turpis at ante porttitor gravida. Aliquam aliquam massa eget blandit feugiat.													', 'default.jpg', 'default.jpg', 'E tudo começou há um tempo atrás na ilha do sol. Destino te mandou de volta para o meu cais. Hiê ê! No coração ficou lembranças de nós dois, como ferida aberta, como tatuagem. Ô Milla! Mil e uma noites de amor com você, na praia, num barco, no farol apagado, num moinho abandonado, em Mar Grande, alto astral... Lá em Hollywood, pra de tudo rolar, vendo estrelas caindo, vendo a noite passar, eu e você, na ilha do sol, na ilha do sol.', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0.00', '', '', 0, 0, 0, 0, 0, '', '2020-02-17 15:17:18'),
(3, 0, '', 'pedroalvaro23@gmail.com', 'cabecadebagre', '', 'pedroalvaro23', 'Pedro', '', '', 'Alvaro', '0000-00-00 00:00:00', 'male', '1988-07-30', '+559083434324', 0, 'Bahamas', 'Crooked Island and Long Cay', 'Colonel Hill', '19th Street, 401, flat 13', 0, 0, '177.13.251.147', '1e6d2782', 1, 0, 0, 0, 0, 0, 0, 0, 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur consectetur aliquam ligula, vitae elementum nisi sollicitudin non. Praesent nunc justo, auctor bibendum dictum sit amet, tempus sed nulla. Nam ac dui pellentesque, euismod sapien consectetur, feugiat ante. Nam risus nibh, dapibus ut gravida id, accumsan at enim. Sed sit amet hendrerit lacus. Vestibulum eget libero sagittis, mollis magna quis, consectetur mi. In vulputate rutrum fermentum. Duis convallis enim at sollicitudin efficitur. In eu velit vel enim tempor accumsan sed et neque. Nullam varius malesuada magna, a convallis mi sodales et. Pellentesque a dolor efficitur, euismod est sed, congue mi. Cras tristique augue sapien, a iaculis nisi elementum quis. Sed quis lectus nisl. Mauris fringilla fringilla ligula non pellentesque. Fusce turpis neque, condimentum eget felis id, tristique sodales ex. Praesent interdum mi a nisi auctor, sagittis placerat leo auctor.  Duis vulputate dictum semper. Etiam ultrices convallis egestas. Aliquam posuere pulvinar magna, ut tempus neque bibendum vel. Morbi ut enim vel nisi fringilla efficitur. Suspendisse gravida ligula ut pretium fermentum. Sed dictum lacus felis, at consequat nisl posuere in. Curabitur sed purus ac felis venenatis euismod quis et enim. Maecenas sollicitudin nulla vel ligula dapibus luctus. Proin pharetra lorem vitae hendrerit finibus. In finibus risus neque, sed pulvinar mauris egestas vitae. Maecenas dignissim, urna quis suscipit porta, lorem tortor mollis nibh, sit amet iaculis nunc sapien non tellus. 					   Sed eu elementum odio. Vestibulum venenatis tellus ac elit finibus gravida. Donec non commodo ex. Sed venenatis sit amet dolor non facilisis. Suspendisse sit amet ultrices dolor. Fusce arcu dui, consectetur at faucibus nec, viverra at dolor. Donec condimentum odio erat, sed vestibulum mauris malesuada tincidunt. Cras convallis venenatis felis vel condimentum. In eget dapibus nunc. Mauris elementum cursus urna, id fringilla arcu euismod sit amet. Sed mollis turpis at ante porttitor gravida. Aliquam aliquam massa eget blandit feugiat.													', 'default.jpg', 'default.jpg', 'E tudo começou há um tempo atrás na ilha do sol. Destino te mandou de volta para o meu cais. Hiê ê! No coração ficou lembranças de nós dois, como ferida aberta, como tatuagem. Ô Milla! Mil e uma noites de amor com você, na praia, num barco, no farol apagado, num moinho abandonado, em Mar Grande, alto astral... Lá em Hollywood, pra de tudo rolar, vendo estrelas caindo, vendo a noite passar, eu e você, na ilha do sol, na ilha do sol.', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0.00', '', '', 0, 0, 0, 0, 0, '', '2020-04-21 20:27:41'),
(4, 0, '', 'allanfreitas2019@gmail.com', 'cabecadebagre', '', 'allan88', 'Allan', '', '', 'Freitas', '0000-00-00 00:00:00', 'male', '1988-07-30', '+5598993435665', 0, 'Afghanistan', 'Nangarhar', 'Markaz-e Woluswali-ye Achin', '19th Street, 401, flat 13', 0, 0, '177.13.251.147', '4a4c993a', 1, 0, 0, 0, 0, 0, 0, 0, 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur consectetur aliquam ligula, vitae elementum nisi sollicitudin non. Praesent nunc justo, auctor bibendum dictum sit amet, tempus sed nulla. Nam ac dui pellentesque, euismod sapien consectetur, feugiat ante. Nam risus nibh, dapibus ut gravida id, accumsan at enim. Sed sit amet hendrerit lacus. Vestibulum eget libero sagittis, mollis magna quis, consectetur mi. In vulputate rutrum fermentum. Duis convallis enim at sollicitudin efficitur. In eu velit vel enim tempor accumsan sed et neque. Nullam varius malesuada magna, a convallis mi sodales et. Pellentesque a dolor efficitur, euismod est sed, congue mi. Cras tristique augue sapien, a iaculis nisi elementum quis. Sed quis lectus nisl. Mauris fringilla fringilla ligula non pellentesque. Fusce turpis neque, condimentum eget felis id, tristique sodales ex. Praesent interdum mi a nisi auctor, sagittis placerat leo auctor.  Duis vulputate dictum semper. Etiam ultrices convallis egestas. Aliquam posuere pulvinar magna, ut tempus neque bibendum vel. Morbi ut enim vel nisi fringilla efficitur. Suspendisse gravida ligula ut pretium fermentum. Sed dictum lacus felis, at consequat nisl posuere in. Curabitur sed purus ac felis venenatis euismod quis et enim. Maecenas sollicitudin nulla vel ligula dapibus luctus. Proin pharetra lorem vitae hendrerit finibus. In finibus risus neque, sed pulvinar mauris egestas vitae. Maecenas dignissim, urna quis suscipit porta, lorem tortor mollis nibh, sit amet iaculis nunc sapien non tellus. 					   Sed eu elementum odio. Vestibulum venenatis tellus ac elit finibus gravida. Donec non commodo ex. Sed venenatis sit amet dolor non facilisis. Suspendisse sit amet ultrices dolor. Fusce arcu dui, consectetur at faucibus nec, viverra at dolor. Donec condimentum odio erat, sed vestibulum mauris malesuada tincidunt. Cras convallis venenatis felis vel condimentum. In eget dapibus nunc. Mauris elementum cursus urna, id fringilla arcu euismod sit amet. Sed mollis turpis at ante porttitor gravida. Aliquam aliquam massa eget blandit feugiat.													', 'default.jpg', 'default.jpg', 'E tudo começou há um tempo atrás na ilha do sol. Destino te mandou de volta para o meu cais. Hiê ê! No coração ficou lembranças de nós dois, como ferida aberta, como tatuagem. Ô Milla! Mil e uma noites de amor com você, na praia, num barco, no farol apagado, num moinho abandonado, em Mar Grande, alto astral... Lá em Hollywood, pra de tudo rolar, vendo estrelas caindo, vendo a noite passar, eu e você, na ilha do sol, na ilha do sol.', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0.00', '', '', 0, 0, 0, 0, 0, '', '2020-04-21 20:27:47'),
(5, 0, '', 'fernandodias7678@gmail.com', 'cabecadebagre', '', 'fernando1234', 'Fernando', '', '', 'Dias', '0000-00-00 00:00:00', 'male', '1990-12-30', '+5576737372494792', 0, 'Australia', 'Australian Capital Territory', 'Federal Capital Territory', '19th Street, 401, flat 13', 0, 0, '177.13.251.147', 'aea4dff7', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur consectetur aliquam ligula, vitae elementum nisi sollicitudin non. Praesent nunc justo, auctor bibendum dictum sit amet, tempus sed nulla. Nam ac dui pellentesque, euismod sapien consectetur, feugiat ante. Nam risus nibh, dapibus ut gravida id, accumsan at enim. Sed sit amet hendrerit lacus. Vestibulum eget libero sagittis, mollis magna quis, consectetur mi. In vulputate rutrum fermentum. Duis convallis enim at sollicitudin efficitur. In eu velit vel enim tempor accumsan sed et neque. Nullam varius malesuada magna, a convallis mi sodales et. Pellentesque a dolor efficitur, euismod est sed, congue mi. Cras tristique augue sapien, a iaculis nisi elementum quis. Sed quis lectus nisl. Mauris fringilla fringilla ligula non pellentesque. Fusce turpis neque, condimentum eget felis id, tristique sodales ex. Praesent interdum mi a nisi auctor, sagittis placerat leo auctor.  Duis vulputate dictum semper. Etiam ultrices convallis egestas. Aliquam posuere pulvinar magna, ut tempus neque bibendum vel. Morbi ut enim vel nisi fringilla efficitur. Suspendisse gravida ligula ut pretium fermentum. Sed dictum lacus felis, at consequat nisl posuere in. Curabitur sed purus ac felis venenatis euismod quis et enim. Maecenas sollicitudin nulla vel ligula dapibus luctus. Proin pharetra lorem vitae hendrerit finibus. In finibus risus neque, sed pulvinar mauris egestas vitae. Maecenas dignissim, urna quis suscipit porta, lorem tortor mollis nibh, sit amet iaculis nunc sapien non tellus. 					   Sed eu elementum odio. Vestibulum venenatis tellus ac elit finibus gravida. Donec non commodo ex. Sed venenatis sit amet dolor non facilisis. Suspendisse sit amet ultrices dolor. Fusce arcu dui, consectetur at faucibus nec, viverra at dolor. Donec condimentum odio erat, sed vestibulum mauris malesuada tincidunt. Cras convallis venenatis felis vel condimentum. In eget dapibus nunc. Mauris elementum cursus urna, id fringilla arcu euismod sit amet. Sed mollis turpis at ante porttitor gravida. Aliquam aliquam massa eget blandit feugiat.													', 'default.jpg', 'default.jpg', 'E tudo começou há um tempo atrás na ilha do sol. Destino te mandou de volta para o meu cais. Hiê ê! No coração ficou lembranças de nós dois, como ferida aberta, como tatuagem. Ô Milla! Mil e uma noites de amor com você, na praia, num barco, no farol apagado, num moinho abandonado, em Mar Grande, alto astral... Lá em Hollywood, pra de tudo rolar, vendo estrelas caindo, vendo a noite passar, eu e você, na ilha do sol, na ilha do sol.', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0.00', '', '', 0, 0, 0, 0, 0, '', '2020-04-21 20:27:53'),
(6, 0, '', 'zacariasbento234@gmail.com', 'cabecadebagre', '', 'zacarias123', 'Zacarias', '', '', 'Bento', '0000-00-00 00:00:00', 'male', '1997-02-28', '+55909394839843', 0, 'Bangladesh', 'Sylhet', 'Jahedpur', '19th Street, 401, flat 13', 0, 0, '177.13.251.147', '49617c64', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur consectetur aliquam ligula, vitae elementum nisi sollicitudin non. Praesent nunc justo, auctor bibendum dictum sit amet, tempus sed nulla. Nam ac dui pellentesque, euismod sapien consectetur, feugiat ante. Nam risus nibh, dapibus ut gravida id, accumsan at enim. Sed sit amet hendrerit lacus. Vestibulum eget libero sagittis, mollis magna quis, consectetur mi. In vulputate rutrum fermentum. Duis convallis enim at sollicitudin efficitur. In eu velit vel enim tempor accumsan sed et neque. Nullam varius malesuada magna, a convallis mi sodales et. Pellentesque a dolor efficitur, euismod est sed, congue mi. Cras tristique augue sapien, a iaculis nisi elementum quis. Sed quis lectus nisl. Mauris fringilla fringilla ligula non pellentesque. Fusce turpis neque, condimentum eget felis id, tristique sodales ex. Praesent interdum mi a nisi auctor, sagittis placerat leo auctor.  Duis vulputate dictum semper. Etiam ultrices convallis egestas. Aliquam posuere pulvinar magna, ut tempus neque bibendum vel. Morbi ut enim vel nisi fringilla efficitur. Suspendisse gravida ligula ut pretium fermentum. Sed dictum lacus felis, at consequat nisl posuere in. Curabitur sed purus ac felis venenatis euismod quis et enim. Maecenas sollicitudin nulla vel ligula dapibus luctus. Proin pharetra lorem vitae hendrerit finibus. In finibus risus neque, sed pulvinar mauris egestas vitae. Maecenas dignissim, urna quis suscipit porta, lorem tortor mollis nibh, sit amet iaculis nunc sapien non tellus. 					   Sed eu elementum odio. Vestibulum venenatis tellus ac elit finibus gravida. Donec non commodo ex. Sed venenatis sit amet dolor non facilisis. Suspendisse sit amet ultrices dolor. Fusce arcu dui, consectetur at faucibus nec, viverra at dolor. Donec condimentum odio erat, sed vestibulum mauris malesuada tincidunt. Cras convallis venenatis felis vel condimentum. In eget dapibus nunc. Mauris elementum cursus urna, id fringilla arcu euismod sit amet. Sed mollis turpis at ante porttitor gravida. Aliquam aliquam massa eget blandit feugiat.													', 'default.jpg', 'default.jpg', 'E tudo começou há um tempo atrás na ilha do sol. Destino te mandou de volta para o meu cais. Hiê ê! No coração ficou lembranças de nós dois, como ferida aberta, como tatuagem. Ô Milla! Mil e uma noites de amor com você, na praia, num barco, no farol apagado, num moinho abandonado, em Mar Grande, alto astral... Lá em Hollywood, pra de tudo rolar, vendo estrelas caindo, vendo a noite passar, eu e você, na ilha do sol, na ilha do sol.', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0.00', '', '', 0, 0, 0, 0, 0, '', '2020-04-21 20:27:59'),
(7, 0, '', 'tobiasbarreto@gmail.com', 'cabecadebagre', '', 'tobias49', 'Tobias', '', '', 'Barreto', '0000-00-00 00:00:00', 'male', '1995-07-30', '+559090394394', 0, 'Barbados', 'Saint James', 'Holetown', '19th Street, 401, flat 13', 0, 0, '177.13.251.147', 'b2f6d71b', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur consectetur aliquam ligula, vitae elementum nisi sollicitudin non. Praesent nunc justo, auctor bibendum dictum sit amet, tempus sed nulla. Nam ac dui pellentesque, euismod sapien consectetur, feugiat ante. Nam risus nibh, dapibus ut gravida id, accumsan at enim. Sed sit amet hendrerit lacus. Vestibulum eget libero sagittis, mollis magna quis, consectetur mi. In vulputate rutrum fermentum. Duis convallis enim at sollicitudin efficitur. In eu velit vel enim tempor accumsan sed et neque. Nullam varius malesuada magna, a convallis mi sodales et. Pellentesque a dolor efficitur, euismod est sed, congue mi. Cras tristique augue sapien, a iaculis nisi elementum quis. Sed quis lectus nisl. Mauris fringilla fringilla ligula non pellentesque. Fusce turpis neque, condimentum eget felis id, tristique sodales ex. Praesent interdum mi a nisi auctor, sagittis placerat leo auctor.  Duis vulputate dictum semper. Etiam ultrices convallis egestas. Aliquam posuere pulvinar magna, ut tempus neque bibendum vel. Morbi ut enim vel nisi fringilla efficitur. Suspendisse gravida ligula ut pretium fermentum. Sed dictum lacus felis, at consequat nisl posuere in. Curabitur sed purus ac felis venenatis euismod quis et enim. Maecenas sollicitudin nulla vel ligula dapibus luctus. Proin pharetra lorem vitae hendrerit finibus. In finibus risus neque, sed pulvinar mauris egestas vitae. Maecenas dignissim, urna quis suscipit porta, lorem tortor mollis nibh, sit amet iaculis nunc sapien non tellus. 					   Sed eu elementum odio. Vestibulum venenatis tellus ac elit finibus gravida. Donec non commodo ex. Sed venenatis sit amet dolor non facilisis. Suspendisse sit amet ultrices dolor. Fusce arcu dui, consectetur at faucibus nec, viverra at dolor. Donec condimentum odio erat, sed vestibulum mauris malesuada tincidunt. Cras convallis venenatis felis vel condimentum. In eget dapibus nunc. Mauris elementum cursus urna, id fringilla arcu euismod sit amet. Sed mollis turpis at ante porttitor gravida. Aliquam aliquam massa eget blandit feugiat.													', 'default.jpg', 'default.jpg', 'E tudo começou há um tempo atrás na ilha do sol. Destino te mandou de volta para o meu cais. Hiê ê! No coração ficou lembranças de nós dois, como ferida aberta, como tatuagem. Ô Milla! Mil e uma noites de amor com você, na praia, num barco, no farol apagado, num moinho abandonado, em Mar Grande, alto astral... Lá em Hollywood, pra de tudo rolar, vendo estrelas caindo, vendo a noite passar, eu e você, na ilha do sol, na ilha do sol.', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0.00', '', '', 0, 0, 0, 0, 0, '', '2020-04-21 20:28:07'),
(8, 0, '', 'carlinhosaguiar@gmail.com', 'cabecadebagre', '', 'carlosaguiar98', 'Carlos', '', '', 'Aguiar', '0000-00-00 00:00:00', 'male', '1998-12-25', '+559898939489', 0, 'Bahrain', 'Manama', 'Sitrah', '19th Street, 401, flat 13', 0, 0, '177.13.251.147', 'e30fe439', 1, 0, 0, 0, 0, 0, 0, 0, 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur consectetur aliquam ligula, vitae elementum nisi sollicitudin non. Praesent nunc justo, auctor bibendum dictum sit amet, tempus sed nulla. Nam ac dui pellentesque, euismod sapien consectetur, feugiat ante. Nam risus nibh, dapibus ut gravida id, accumsan at enim. Sed sit amet hendrerit lacus. Vestibulum eget libero sagittis, mollis magna quis, consectetur mi. In vulputate rutrum fermentum. Duis convallis enim at sollicitudin efficitur. In eu velit vel enim tempor accumsan sed et neque. Nullam varius malesuada magna, a convallis mi sodales et. Pellentesque a dolor efficitur, euismod est sed, congue mi. Cras tristique augue sapien, a iaculis nisi elementum quis. Sed quis lectus nisl. Mauris fringilla fringilla ligula non pellentesque. Fusce turpis neque, condimentum eget felis id, tristique sodales ex. Praesent interdum mi a nisi auctor, sagittis placerat leo auctor.  Duis vulputate dictum semper. Etiam ultrices convallis egestas. Aliquam posuere pulvinar magna, ut tempus neque bibendum vel. Morbi ut enim vel nisi fringilla efficitur. Suspendisse gravida ligula ut pretium fermentum. Sed dictum lacus felis, at consequat nisl posuere in. Curabitur sed purus ac felis venenatis euismod quis et enim. Maecenas sollicitudin nulla vel ligula dapibus luctus. Proin pharetra lorem vitae hendrerit finibus. In finibus risus neque, sed pulvinar mauris egestas vitae. Maecenas dignissim, urna quis suscipit porta, lorem tortor mollis nibh, sit amet iaculis nunc sapien non tellus. 					   Sed eu elementum odio. Vestibulum venenatis tellus ac elit finibus gravida. Donec non commodo ex. Sed venenatis sit amet dolor non facilisis. Suspendisse sit amet ultrices dolor. Fusce arcu dui, consectetur at faucibus nec, viverra at dolor. Donec condimentum odio erat, sed vestibulum mauris malesuada tincidunt. Cras convallis venenatis felis vel condimentum. In eget dapibus nunc. Mauris elementum cursus urna, id fringilla arcu euismod sit amet. Sed mollis turpis at ante porttitor gravida. Aliquam aliquam massa eget blandit feugiat.													', 'default.jpg', 'default.jpg', 'E tudo começou há um tempo atrás na ilha do sol. Destino te mandou de volta para o meu cais. Hiê ê! No coração ficou lembranças de nós dois, como ferida aberta, como tatuagem. Ô Milla! Mil e uma noites de amor com você, na praia, num barco, no farol apagado, num moinho abandonado, em Mar Grande, alto astral... Lá em Hollywood, pra de tudo rolar, vendo estrelas caindo, vendo a noite passar, eu e você, na ilha do sol, na ilha do sol.', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0.00', '', '', 0, 0, 0, 0, 0, '', '2020-04-21 20:28:14'),
(9, 0, '', 'gilbertomattos@gmail.com', 'cabecadebagre', '', 'gilberto123', 'Gilberto', '', '', 'Mattos', '0000-00-00 00:00:00', 'male', '1999-09-20', '+550909394024', 0, 'Bangladesh', 'Chittagong', 'Laksham', '19th Street, 401, flat 13', 1, 0, '177.13.251.147', 'b84ac4bf', 1, 0, 0, 0, 0, 0, 0, 0, 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur consectetur aliquam ligula, vitae elementum nisi sollicitudin non. Praesent nunc justo, auctor bibendum dictum sit amet, tempus sed nulla. Nam ac dui pellentesque, euismod sapien consectetur, feugiat ante. Nam risus nibh, dapibus ut gravida id, accumsan at enim. Sed sit amet hendrerit lacus. Vestibulum eget libero sagittis, mollis magna quis, consectetur mi. In vulputate rutrum fermentum. Duis convallis enim at sollicitudin efficitur. In eu velit vel enim tempor accumsan sed et neque. Nullam varius malesuada magna, a convallis mi sodales et. Pellentesque a dolor efficitur, euismod est sed, congue mi. Cras tristique augue sapien, a iaculis nisi elementum quis. Sed quis lectus nisl. Mauris fringilla fringilla ligula non pellentesque. Fusce turpis neque, condimentum eget felis id, tristique sodales ex. Praesent interdum mi a nisi auctor, sagittis placerat leo auctor.  Duis vulputate dictum semper. Etiam ultrices convallis egestas. Aliquam posuere pulvinar magna, ut tempus neque bibendum vel. Morbi ut enim vel nisi fringilla efficitur. Suspendisse gravida ligula ut pretium fermentum. Sed dictum lacus felis, at consequat nisl posuere in. Curabitur sed purus ac felis venenatis euismod quis et enim. Maecenas sollicitudin nulla vel ligula dapibus luctus. Proin pharetra lorem vitae hendrerit finibus. In finibus risus neque, sed pulvinar mauris egestas vitae. Maecenas dignissim, urna quis suscipit porta, lorem tortor mollis nibh, sit amet iaculis nunc sapien non tellus. 					   Sed eu elementum odio. Vestibulum venenatis tellus ac elit finibus gravida. Donec non commodo ex. Sed venenatis sit amet dolor non facilisis. Suspendisse sit amet ultrices dolor. Fusce arcu dui, consectetur at faucibus nec, viverra at dolor. Donec condimentum odio erat, sed vestibulum mauris malesuada tincidunt. Cras convallis venenatis felis vel condimentum. In eget dapibus nunc. Mauris elementum cursus urna, id fringilla arcu euismod sit amet. Sed mollis turpis at ante porttitor gravida. Aliquam aliquam massa eget blandit feugiat.													', 'default.jpg', 'default.jpg', 'E tudo começou há um tempo atrás na ilha do sol. Destino te mandou de volta para o meu cais. Hiê ê! No coração ficou lembranças de nós dois, como ferida aberta, como tatuagem. Ô Milla! Mil e uma noites de amor com você, na praia, num barco, no farol apagado, num moinho abandonado, em Mar Grande, alto astral... Lá em Hollywood, pra de tudo rolar, vendo estrelas caindo, vendo a noite passar, eu e você, na ilha do sol, na ilha do sol.', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0.00', '', '', 0, 0, 0, 0, 0, '', '2020-04-21 20:28:22'),
(10, 0, '', 'mundicaobarretos@hotmail.com', 'cabecadebagre', '', 'mundicao49', 'Raimundo', '', '', 'Barreto', '0000-00-00 00:00:00', 'masculino', '1999-05-20', '', 0, '', '', '', '', 0, 0, '::1', 'ba7eccfa', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur consectetur aliquam ligula, vitae elementum nisi sollicitudin non. Praesent nunc justo, auctor bibendum dictum sit amet, tempus sed nulla. Nam ac dui pellentesque, euismod sapien consectetur, feugiat ante. Nam risus nibh, dapibus ut gravida id, accumsan at enim. Sed sit amet hendrerit lacus. Vestibulum eget libero sagittis, mollis magna quis, consectetur mi. In vulputate rutrum fermentum. Duis convallis enim at sollicitudin efficitur. In eu velit vel enim tempor accumsan sed et neque. Nullam varius malesuada magna, a convallis mi sodales et. Pellentesque a dolor efficitur, euismod est sed, congue mi. Cras tristique augue sapien, a iaculis nisi elementum quis. Sed quis lectus nisl. Mauris fringilla fringilla ligula non pellentesque. Fusce turpis neque, condimentum eget felis id, tristique sodales ex. Praesent interdum mi a nisi auctor, sagittis placerat leo auctor.  Duis vulputate dictum semper. Etiam ultrices convallis egestas. Aliquam posuere pulvinar magna, ut tempus neque bibendum vel. Morbi ut enim vel nisi fringilla efficitur. Suspendisse gravida ligula ut pretium fermentum. Sed dictum lacus felis, at consequat nisl posuere in. Curabitur sed purus ac felis venenatis euismod quis et enim. Maecenas sollicitudin nulla vel ligula dapibus luctus. Proin pharetra lorem vitae hendrerit finibus. In finibus risus neque, sed pulvinar mauris egestas vitae. Maecenas dignissim, urna quis suscipit porta, lorem tortor mollis nibh, sit amet iaculis nunc sapien non tellus. 					   Sed eu elementum odio. Vestibulum venenatis tellus ac elit finibus gravida. Donec non commodo ex. Sed venenatis sit amet dolor non facilisis. Suspendisse sit amet ultrices dolor. Fusce arcu dui, consectetur at faucibus nec, viverra at dolor. Donec condimentum odio erat, sed vestibulum mauris malesuada tincidunt. Cras convallis venenatis felis vel condimentum. In eget dapibus nunc. Mauris elementum cursus urna, id fringilla arcu euismod sit amet. Sed mollis turpis at ante porttitor gravida. Aliquam aliquam massa eget blandit feugiat.													', 'default.jpg', 'default.jpg', 'E tudo começou há um tempo atrás na ilha do sol. Destino te mandou de volta para o meu cais. Hiê ê! No coração ficou lembranças de nós dois, como ferida aberta, como tatuagem. Ô Milla! Mil e uma noites de amor com você, na praia, num barco, no farol apagado, num moinho abandonado, em Mar Grande, alto astral... Lá em Hollywood, pra de tudo rolar, vendo estrelas caindo, vendo a noite passar, eu e você, na ilha do sol, na ilha do sol.', 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0.00', '', '', 0, 0, 0, 0, 0, '', '2020-04-21 20:28:31');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `fotos`
--
ALTER TABLE `fotos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `ipn_notifications`
--
ALTER TABLE `ipn_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `paypalswitch`
--
ALTER TABLE `paypalswitch`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios_cadastrados`
--
ALTER TABLE `usuarios_cadastrados`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `fotos`
--
ALTER TABLE `fotos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `ipn_notifications`
--
ALTER TABLE `ipn_notifications`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=663;

--
-- AUTO_INCREMENT de tabela `paypalswitch`
--
ALTER TABLE `paypalswitch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `usuarios_cadastrados`
--
ALTER TABLE `usuarios_cadastrados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
